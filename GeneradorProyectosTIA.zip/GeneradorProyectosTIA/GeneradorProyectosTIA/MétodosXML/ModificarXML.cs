﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;


namespace GeneradorProyectosTIA.MétodosXML
{
    class ModificarXML
    {
        public static string path { get; set; } = Directory.GetCurrentDirectory();

        #region Funciones comunes
        private static XmlDocument CambiarNombreFB(XmlDocument XmlFB, string nombre)
        {
            XmlNode NombreFB = XmlFB.SelectSingleNode("//Document//SW.Blocks.FB//AttributeList//Name");
            NombreFB.InnerText = nombre;
            return XmlFB;
        }
        private static XmlDocument CambiarNombreOB(XmlDocument XmlFB, string nombre)
        {
            XmlNode NombreFB = XmlFB.SelectSingleNode("//Document//SW.Blocks.OB//AttributeList//Name");
            NombreFB.InnerText = nombre;
            return XmlFB;
        }
        private static XmlDocument AñadirEstacion(XmlDocument XmlFB, XmlDocument XmlEstacion)
        {
            // AÑADIR LAS ETAPAS
            XmlNodeList Nodos = XmlEstacion.SelectSingleNode("//Sequence//Steps").ChildNodes;

            XmlNode NodoRef = XmlFB.SelectSingleNode("//*[name(.)='Steps']");

            foreach (XmlNode Nodo in Nodos)
            {
                XmlNode nodoImportado = XmlFB.ImportNode(Nodo, true);
                NodoRef.InsertBefore(nodoImportado, NodoRef.LastChild);
            }

            // AÑADIR LAS TRANSICIONES
            Nodos = XmlEstacion.SelectSingleNode("//Sequence//Transitions").ChildNodes;

            NodoRef = XmlFB.SelectSingleNode("//*[name(.)='Transitions']");

            foreach (XmlNode Nodo in Nodos)
            {
                XmlNode nodoImportado = XmlFB.ImportNode(Nodo, true);
                NodoRef.InsertBefore(nodoImportado, NodoRef.LastChild.PreviousSibling);
            }

            // AÑADIR LAS CONEXIONES
            Nodos = XmlEstacion.SelectSingleNode("//Sequence//Connections").ChildNodes;
            XmlNode NodoConexiones = XmlFB.SelectSingleNode("//*[name(.)='Connections']");

            XmlNodeList NodosFrom = XmlFB.SelectNodes("//*[name(.)='NodeFrom']");
            foreach (XmlNode NodoFrom in NodosFrom)
            {
                if (NodoFrom.FirstChild.Name == "BranchRef" && NodoFrom.FirstChild.Attributes["Number"].Value == "2")
                {
                    // Insertaremos la conexión justo antes de que se cierre la rama AND del Grafcet
                    NodoRef = NodoFrom.ParentNode;
                }
            }

            foreach (XmlNode Nodo in Nodos)
            {
                XmlNode nodoImportado = XmlFB.ImportNode(Nodo, true);
                NodoRef.AppendChild(nodoImportado);
                NodoConexiones.InsertBefore(nodoImportado, NodoRef);
            }

            return XmlFB;
        }
        private static XmlDocument RenumerarEtapas_GRAPH(XmlDocument XmlFB, int etapa_inicial)
        {
            XmlNodeList Nodos = XmlFB.SelectNodes("//*[name(.)='Step']");

            int num = 1;
            foreach (XmlNode Nodo in Nodos)
            {
                Nodo.Attributes["Name"].Value = "X" + etapa_inicial;
                Nodo.Attributes["Number"].Value = num.ToString();
                etapa_inicial++;
                num++;
            }

            return XmlFB;
        }
        private static XmlDocument RenumerarTransiciones_GRAPH(XmlDocument XmlFB)
        {
            XmlNodeList Nodos = XmlFB.SelectNodes("//*[name(.)='Transition']");

            int num = 1;
            foreach (XmlNode Nodo in Nodos)
            {
                Nodo.Attributes["Name"].Value = "Trans" + num;
                Nodo.Attributes["Number"].Value = num.ToString();
                num++;
            }

            return XmlFB;
        }
        private static XmlDocument AjustarCantidadRamas_GRAPH(XmlDocument XmlFB, int cantidad)
        {
            XmlNode NodoRama = XmlFB.SelectSingleNode("//*[name(.)='Branches']");

            if (cantidad > 1)
            {
                foreach (XmlNode Nodo in NodoRama.ChildNodes)
                {
                    Nodo.Attributes["Cardinality"].Value = cantidad.ToString();
                }
            }
            else
            {
                NodoRama.RemoveAll();
            }

            return XmlFB;
        }
        private static XmlDocument ModificarConexiones_GRAPH(XmlDocument XmlFB)
        {
            #region Renumerar los nodos "NodeFrom" de las conexiones
            XmlNodeList NodesFrom = XmlFB.SelectNodes("//*[name(.)='NodeFrom']");
            int numStep = 1;
            int numTrans = 1;
            int numBranch = 0;

            foreach (XmlNode NodeFrom in NodesFrom)
            {
                if (NodeFrom.FirstChild.Name == "StepRef")
                {
                    NodeFrom.FirstChild.Attributes["Number"].Value = numStep.ToString();
                    numStep++;
                }
                if (NodeFrom.FirstChild.Name == "TransitionRef")
                {
                    NodeFrom.FirstChild.Attributes["Number"].Value = numTrans.ToString();
                    numTrans++;
                }
                if (NodeFrom.FirstChild.Name == "BranchRef")
                {
                    if (NodeFrom.FirstChild.Attributes["Number"].Value == "1")
                    {
                        NodeFrom.FirstChild.Attributes["Out"].Value = numBranch.ToString();
                        numBranch++;
                    }
                }
            }
            #endregion

            #region Renumerar los nodos "NodeTo" de las conexiones
            XmlNodeList NodesTo = XmlFB.SelectNodes("//*[name(.)='NodeTo']");
            numStep = 2;
            numTrans = 1;
            numBranch = 0;

            foreach (XmlNode NodeTo in NodesTo)
            {
                if (NodeTo.FirstChild.Name == "StepRef")
                {
                    if (NodeTo.NextSibling.InnerText == "Jump")
                    {
                        // El número del Step tiene que ser 1 porque hay un salto (Jump) desde la última transición hasta la primera etapa.
                        NodeTo.FirstChild.Attributes["Number"].Value = "1";
                    }
                    else
                    {
                        NodeTo.FirstChild.Attributes["Number"].Value = numStep.ToString();
                        numStep++;
                    }
                }
                if (NodeTo.FirstChild.Name == "TransitionRef")
                {
                    NodeTo.FirstChild.Attributes["Number"].Value = numTrans.ToString();
                    numTrans++;
                }
                if (NodeTo.FirstChild.Name == "BranchRef")
                {
                    if (NodeTo.FirstChild.Attributes["Number"].Value == "2")
                    {
                        NodeTo.FirstChild.Attributes["In"].Value = numBranch.ToString();
                        numBranch++;
                    }
                }
            }
            #endregion

            return XmlFB;
        }
        private static XmlDocument AjustarParámetrosEstáticos_FB(XmlDocument XmlFB)
        {
            bool existeNodo = false;
            List<XmlNode> nodosParaEliminar = new List<XmlNode>();

            XmlNode NodoParámetrosEstáticos = XmlFB.DocumentElement.SelectSingleNode("/Document//SW.Blocks.FB//AttributeList//Interface").FirstChild.SelectNodes("descendant::*[@Name='Static']")[1];

            #region Eliminar los parámetros de tipo Etapa que no se usan
            XmlNodeList nodosParámetros = NodoParámetrosEstáticos.ChildNodes;
            XmlNodeList NodosEtapas = XmlFB.SelectNodes("//*[name(.)='Step']");

            foreach (XmlNode nodoParámetro in nodosParámetros)
            {
                if (nodoParámetro.Attributes["Name"].Value.Contains("X"))
                {
                    foreach (XmlNode NodoEtapa in NodosEtapas)
                    {
                        if (nodoParámetro.Attributes["Name"].Value == NodoEtapa.Attributes["Name"].Value)
                        {
                            // Esta etapa se ha utilizado en el Grafcet. No borrar.
                            existeNodo = true;
                            break;
                        }
                    }

                    if (!existeNodo)
                    {
                        // Esta etapa no se ha utilizado en el Grafcet. Borrar.
                        nodosParaEliminar.Add(nodoParámetro);
                    }
                }
                existeNodo = false;
            }
            #endregion

            #region Eliminar los parámetros de tipo Transición que no se usan
            XmlNodeList NodosTransiciones = XmlFB.SelectNodes("//*[name(.)='Transition']");

            foreach (XmlNode nodoParámetro in nodosParámetros)
            {
                if (nodoParámetro.Attributes["Name"].Value.Contains("Trans"))
                {
                    foreach (XmlNode NodoTransición in NodosTransiciones)
                    {
                        if (nodoParámetro.Attributes["Name"].Value == NodoTransición.Attributes["Name"].Value)
                        {
                            // Esta transición se ha utilizado en el Grafcet. No borrar.
                            existeNodo = true;
                            break;
                        }
                    }

                    if (!existeNodo)
                    {
                        // Esta transición no se ha utilizado en el Grafcet. Borrar.
                        nodosParaEliminar.Add(nodoParámetro);
                    }
                }
                existeNodo = false;
            }

            #endregion

            // Eliminar los nodos marcados
            foreach (XmlNode nodoParaEliminar in nodosParaEliminar)
            {
                NodoParámetrosEstáticos.RemoveChild(nodoParaEliminar);
            }

            return XmlFB;
        }
        #endregion

        #region Modificar Grafcet de Condiciones Iniciales del Control General
        public static void GenerarGrafcetCondIni(int[] estaciones)
        {
            // Creamos un documento XML y cargamos la plantilla
            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_CondIniciales Plantilla.xml");

            // Cambiamos el nombre del FB
            XmlDoc = CambiarNombreFB(XmlDoc, "GCG_CondIniciales");

            // Añadimos a la plantilla el código correspondiente a las estaciones que se quieren añadir
            AñadirEstacionesCondIni(XmlDoc, estaciones);

            // Guardamos el documento XML Final
            XmlDoc.Save(path + "\\Programas\\PLC\\ProgramBlocks\\CG Celula\\FBs\\GCG_CondIniciales.xml");
            //XmlDoc.Save("F:\\TFM\\ImportarXML\\GCG_CondIniciales.xml");
        }
        private static XmlDocument AñadirEstacionesCondIni(XmlDocument XmlFB, int[] estaciones)
        {
            int num = 0; // Cantidad de estaciones

            // Añadir las ramas del grafcet correspondientes a las estaciones seleccionadas
            for (int i = 0; i < estaciones.Length; i++)
            { 
                if(estaciones[i] > 0)
                {
                    XmlFB = AñadirEstacionCondIni(XmlFB, i);
                    num++;
                }
            }

            // Renumerar y renombrar los Step
            XmlFB = RenumerarEtapas_GRAPH(XmlFB, 1010);

            // Renumerar y renombrar las transiciones
            XmlFB = RenumerarTransiciones_GRAPH(XmlFB);

            // Ajustar la cantidad de ramas del grafcet (Branches)
            XmlFB = AjustarCantidadRamas_GRAPH(XmlFB, num);

            // Renumerar y renombrar las conexiones
            XmlFB = ModificarConexiones_GRAPH(XmlFB);

            // Ajustar parámetros estáticos
            XmlFB = AjustarParámetrosEstáticos_FB(XmlFB);

            return XmlFB;
        }
        private static XmlDocument AñadirEstacionCondIni(XmlDocument XmlFB, int tipo_estacion)
        {
            XmlDocument XmlEstacion = new XmlDocument();

            switch (tipo_estacion)
            {
                case 0:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_CondIniciales Estación S1.xml");
                    break;
                case 1:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_CondIniciales Estación S2.xml");
                    break;
                case 2:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_CondIniciales Estación S3.xml");
                    break;
                case 3:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_CondIniciales Estación S4.xml");
                    break;
                case 4:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_CondIniciales Estación ST.xml");
                    break;
                default:
                    break;
            }

            if (XmlEstacion.DocumentElement != null)
            {
                // Añadimos la estación en caso de que se haya cargado algún archivo XML en XmlEstacion
                XmlFB = AñadirEstacion(XmlFB, XmlEstacion);
            }

            return XmlFB;
        }
        #endregion


        #region Modificar Grafcet de Marcha de Preparación del Control General
        public static void GenerarGrafcetMarchaPre(int[] cantidad)
        {
            // Creamos un documento XML y cargamos la plantilla
            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_MarchaPre Plantilla.xml");

            // Cambiamos el nombre del FB
            XmlDoc = CambiarNombreFB(XmlDoc, "GCG_MarchaPre");

            // Añadimos a la plantilla el código correspondiente a las estaciones que se quieren añadir
            AñadirEstacionesMarchaPre(XmlDoc, cantidad);

            // Guardamos el documento XML Final
            XmlDoc.Save(path + "\\Programas\\PLC\\ProgramBlocks\\CG Celula\\FBs\\GCG_MarchaPre.xml");
            //XmlDoc.Save("F:\\TFM\\ImportarXML\\GCG_MarchaPre.xml");
        }
        private static XmlDocument AñadirEstacionesMarchaPre(XmlDocument XmlFB, int[] estaciones)
        {
            int num = 0; // Cantidad de estaciones

            // Añadir las ramas del grafcet correspondientes a las estaciones seleccionadas.
            // El Sistema de Transporte no tiene Marcha de Preparación. Por eso el bucle FOR es de 0 a estaciones.Length-1.
            for (int i = 0; i < estaciones.Length-1; i++)
            {
                if (estaciones[i] > 0)
                {
                    XmlFB = AñadirEstacionMarchaPre(XmlFB, i);
                    num++;
                }
            }

            // Renumerar y renombrar los Step
            XmlFB = RenumerarEtapas_GRAPH(XmlFB, 1030);

            // Renumerar y renombrar las transiciones
            XmlFB = RenumerarTransiciones_GRAPH(XmlFB);

            // Ajustar la cantidad de ramas del grafcet (Branches)
            XmlFB = AjustarCantidadRamas_GRAPH(XmlFB, num+1); // Num+1 porque MarchaPre tiene una rama adicional independiente de las estaciones.

            // Renumerar y renombrar las conexiones
            XmlFB = ModificarConexiones_GRAPH(XmlFB);

            // Ajustar parámetros estáticos
            XmlFB = AjustarParámetrosEstáticos_FB(XmlFB);

            return XmlFB;
        }
        private static XmlDocument AñadirEstacionMarchaPre(XmlDocument XmlFB, int tipo_estacion)
        {
            XmlDocument XmlEstacion = new XmlDocument();

            switch (tipo_estacion)
            {
                case 0:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_MarchaPre Estación S1.xml");
                    break;
                case 1:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_MarchaPre Estación S2.xml");
                    break;
                case 2:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_MarchaPre Estación S3.xml");
                    break;
                case 3:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_MarchaPre Estación S4.xml");
                    break;
                default:
                    break;
            }

            if(XmlEstacion.DocumentElement != null)
            {
                // Añadimos la estación en caso de que se haya cargado algún archivo XML en XmlEstacion
                XmlFB = AñadirEstacion(XmlFB, XmlEstacion);
            }


            return XmlFB;
        }
        #endregion


        #region Modificar Grafcet de Producción Normal del Control General 
        public static void GenerarGrafcetProdNorm(int[] cantidad)
        {
            // Creamos un documento XML y cargamos la plantilla
            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_ActivarProdNorm Plantilla.xml");

            // Cambiamos el nombre del FB
            XmlDoc = CambiarNombreFB(XmlDoc, "GCG_ActivarProdNorm");

            // Añadimos a la plantilla el código correspondiente a las estaciones que se quieren añadir
            AñadirEstacionesProdNorm(XmlDoc, cantidad);

            // Guardamos el documento XML Final
            XmlDoc.Save(path + "\\Programas\\PLC\\ProgramBlocks\\CG Celula\\FBs\\GCG_ActivarProdNorm.xml");
            //XmlDoc.Save("F:\\TFM\\ImportarXML\\GCG_ActivarProdNorm.xml");
        }
        private static XmlDocument AñadirEstacionesProdNorm(XmlDocument XmlFB, int[] estaciones)
        {
            int num = 0; // Cantidad de estaciones

            // Añadir las ramas del grafcet correspondientes a las estaciones seleccionadas.
            for (int i = 0; i < estaciones.Length; i++)
            {
                if (estaciones[i] > 0)
                {
                    XmlFB = AñadirEstacionProdNorm(XmlFB, i);
                    num++;
                }
            }

            // Renumerar y renombrar los Step
            XmlFB = RenumerarEtapas_GRAPH(XmlFB, 1050);

            // Renumerar y renombrar las transiciones
            XmlFB = RenumerarTransiciones_GRAPH(XmlFB);

            // Ajustar la cantidad de ramas del grafcet (Branches)
            XmlFB = AjustarCantidadRamas_GRAPH(XmlFB, num);

            // Renumerar y renombrar las conexiones
            XmlFB = ModificarConexiones_GRAPH(XmlFB);

            // Ajustar parámetros estáticos
            XmlFB = AjustarParámetrosEstáticos_FB(XmlFB);

            return XmlFB;
        }
        private static XmlDocument AñadirEstacionProdNorm(XmlDocument XmlFB, int tipo_estacion)
        {
            XmlDocument XmlEstacion = new XmlDocument();

            switch (tipo_estacion)
            {
                case 0:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_ActivarProdNorm Estación S1.xml");
                    break;
                case 1:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_ActivarProdNorm Estación S2.xml");
                    break;
                case 2:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_ActivarProdNorm Estación S3.xml");
                    break;
                case 3:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_ActivarProdNorm Estación S4.xml");
                    break;
                case 4:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_ActivarProdNorm Estación ST.xml");
                    break;
                default:
                    break;
            }

            if (XmlEstacion.DocumentElement != null)
            {
                // Añadimos la estación en caso de que se haya cargado algún archivo XML en XmlEstacion
                XmlFB = AñadirEstacion(XmlFB, XmlEstacion);
            }

            return XmlFB;
        }
        #endregion

        #region Modificar Grafcet de Emergencia del Control General
        public static void GenerarGrafcetEmergencia(int[] cantidad)
        {
            // Creamos un documento XML y cargamos la plantilla
            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_Emergencia Plantilla.xml");

            // Cambiamos el nombre del FB
            XmlDoc = CambiarNombreFB(XmlDoc, "GCG_Emergencia");

            // Añadimos a la plantilla el código correspondiente a las estaciones que se quieren añadir
            AñadirEstacionesEmergencia(XmlDoc, cantidad);

            // Guardamos el documento XML Final
            XmlDoc.Save(path + "\\Programas\\PLC\\ProgramBlocks\\CG Celula\\FBs\\GCG_Emergencia.xml");
            //XmlDoc.Save("F:\\TFM\\ImportarXML\\GCG_Emergencia.xml");
        }
        private static XmlDocument AñadirEstacionesEmergencia(XmlDocument XmlFB, int[] estaciones)
        {
            int num = 0; // Cantidad de estaciones

            // Añadir las ramas del grafcet correspondientes a las estaciones seleccionadas.
            for (int i = 0; i < estaciones.Length; i++)
            {
                if (estaciones[i] > 0)
                {
                    XmlFB = AñadirEstacionEmergencia(XmlFB, i);
                    if(i != 1 && i != 3)
                    {
                        // La emergencia no está preparada aún para las estaciones S2 y S4, es decir, no hay una ramas en el grafcet correspondientes a esas estaciones.
                        // Por eso no se aumenta el índice num en esos casos.
                        num++;
                    }
                }
            }

            // Renumerar y renombrar los Step
            XmlFB = RenumerarEtapas_GRAPH(XmlFB, 1100);

            // Renumerar y renombrar las transiciones
            XmlFB = RenumerarTransiciones_GRAPH(XmlFB);

            // Ajustar la cantidad de ramas del grafcet (Branches)
            XmlFB = AjustarCantidadRamas_GRAPH(XmlFB, num);

            // Renumerar y renombrar las conexiones
            XmlFB = ModificarConexiones_GRAPH(XmlFB);

            // Ajustar parámetros estáticos
            XmlFB = AjustarParámetrosEstáticos_FB(XmlFB);

            return XmlFB;
        }
        private static XmlDocument AñadirEstacionEmergencia(XmlDocument XmlFB, int tipo_estacion)
        {
            XmlDocument XmlEstacion = new XmlDocument();

            // Por el momento la emergencia sólo está preparada para las estacioens S1, S3 y ST.
            switch (tipo_estacion)
            {
                case 0:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_Emergencia Estación S1.xml");
                    break;
                case 2:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_Emergencia Estación S3.xml");
                    break;
                case 4:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_Emergencia Estación ST.xml");
                    break;
                default:
                    break;
            }

            if (XmlEstacion.DocumentElement != null)
            {
                // Añadimos la estación en caso de que se haya cargado algún archivo XML en XmlEstacion
                XmlFB = AñadirEstacion(XmlFB, XmlEstacion);
            }

            return XmlFB;
        }
        #endregion

        #region Modificar el Main
        public static void GenerarProgramaOB1(int[] estaciones)
        {
            // Creamos un documento XML y cargamos la plantilla
            XmlDocument XmlDoc = new XmlDocument();
            XmlDoc.Load(path + "\\PlantillasXML\\Programas PLC\\Componentes CG Plantilla.xml");

            // Cambiamos el nombre del OB
            XmlDoc = CambiarNombreOB(XmlDoc, "Componentes CG");

            // Añadimos a la plantilla el código correspondiente a las estaciones que se quieren añadir
            AñadirEstacionesOB1(XmlDoc, estaciones);

            // Guardamos el documento XML Final
            XmlDoc.Save(path + "\\Programas\\PLC\\ProgramBlocks\\Otros\\FBs\\Componentes CG.xml");
            //XmlDoc.Save("F:\\TFM\\ImportarXML\\Componentes CG.xml");
        }
        private static XmlDocument AñadirEstacionesOB1(XmlDocument XmlOB, int[] estaciones)
        {
            for (int i = 0; i < estaciones.Length; i++)
            {
                if (estaciones[i] > 0)
                {
                    XmlOB = AñadirEstacionOB1(XmlOB, i);
                }
            }

            // Renumerar/Renombrar las etapas, transiciones, ramas (branches) y conexiones
            XmlOB = RenumerarObjetosOB(XmlOB);

            return XmlOB;
        }
        private static XmlDocument AñadirEstacionOB1(XmlDocument XmlOB, int tipo_estacion)
        {
            XmlDocument XmlEstacion = new XmlDocument();

            // Abrir la plantilla del tipo de estación que hay que añadir
            switch (tipo_estacion)
            {
                case 0:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\Componentes CG Estación S1.xml");
                    break;
                case 1:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\Componentes CG Estación S2.xml");
                    break;
                case 2:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\Componentes CG Estación S3.xml");
                    break;
                case 3:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\Componentes CG Estación S4.xml");
                    break;
                case 4:
                    XmlEstacion.Load(path + "\\PlantillasXML\\Programas PLC\\Componentes CG Estación ST.xml");
                    break;
                default:
                    break;
            }

            if (XmlEstacion.DocumentElement != null)
            {
                // AÑADIR LA INSTANCIA DEL OB Y RENOMBRAR EL DB DE INSTANCIA
                XmlNode NodoEstación = XmlEstacion.SelectSingleNode("//Document").FirstChild;

                XmlNode NodoRef = XmlOB.SelectSingleNode("//*[name(.)='ObjectList']");

                //// Renombrar el DB
                //XmlNode NodoInstancia = XmlEstacion.SelectSingleNode("//*[name(.)='Call']").SelectSingleNode("descendant::*[name(.) = 'Instance']");
                //NodoInstancia.FirstChild.Attributes["Name"].Value = "S1_Ubicacion Base_GF_DB_" + numero;

                XmlNode nodoImportado = XmlOB.ImportNode(NodoEstación, true);
                NodoRef.InsertBefore(nodoImportado, NodoRef.LastChild.PreviousSibling);
            }
            
            return XmlOB;
        }
        private static XmlDocument RenumerarObjetosOB(XmlDocument XmlOB)
        {
            XmlNodeList Nodos = XmlOB.SelectNodes("//*[@ID]");

            byte i = 0x00;
            foreach (XmlNode Nodo in Nodos)
            {
                Nodo.Attributes["ID"].Value = i.ToString("X");
                i++;
            }

            return XmlOB;
        }
        #endregion

        #region Modificar Grafcets de Posiciones: PosS1, PosS2, PosS3, PosS4
        public static void GenerarGrafcetsPos(int[] estaciones)
        {
            // Generar grafcet PosS1
            GenerarGrafcetPosS1(estaciones[0]);

            // Generar grafcet PosS2
            GenerarGrafcetPosS2(estaciones[1]);

            // Generar grafcet PosS3
            GenerarGrafcetPosS3(estaciones[2]);

            // Generar grafcet PosS4
            GenerarGrafcetPosS4(estaciones[3]);
        }
        private static void GenerarGrafcetPosS1(int estacion)
        {
            XmlDocument XmlFB = new XmlDocument();

            if(estacion == 0)
            {
                XmlFB.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_PosS1sinEstacionS1.xml");
            }

            if(estacion == 1)
            {
                XmlFB.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_PosS1conEstacionS1.xml");
            }

            XmlFB = CambiarNombreFB(XmlFB, "GCG_PosS1");

            XmlFB.Save(path + "\\Programas\\PLC\\ProgramBlocks\\CG Celula\\FBs\\GCG_PosS1.xml");
            //XmlFB.Save("F:\\TFM\\ImportarXML\\GCG_PosS1.xml");
        }
        private static void GenerarGrafcetPosS2(int estacion)
        {
            XmlDocument XmlFB = new XmlDocument();

            if (estacion == 0)
            {
                XmlFB.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_PosS2sinEstacionS2.xml");
            }

            if (estacion == 1)
            {
                XmlFB.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_PosS2conEstacionS2_Rodamiento.xml");
            }

            if (estacion == 2)
            {
                XmlFB.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_PosS2conEstacionS2_Eje_Rodamiento.xml");
            }

            XmlFB = CambiarNombreFB(XmlFB, "GCG_PosS2");

            XmlFB.Save(path + "\\Programas\\PLC\\ProgramBlocks\\CG Celula\\FBs\\GCG_PosS2.xml");
            //XmlFB.Save("F:\\TFM\\ImportarXML\\GCG_PosS2.xml");
        }
        private static void GenerarGrafcetPosS3(int estacion)
        {
            XmlDocument XmlFB = new XmlDocument();

            if (estacion == 0)
            {
                XmlFB.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_PosS3sinEstacionS3.xml");
            }

            if (estacion == 1)
            {
                XmlFB.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_PosS3conEstacionS3.xml");
            }

            XmlFB = CambiarNombreFB(XmlFB, "GCG_PosS3");

            XmlFB.Save(path + "\\Programas\\PLC\\ProgramBlocks\\CG Celula\\FBs\\GCG_PosS3.xml");
            //XmlFB.Save("F:\\TFM\\ImportarXML\\GCG_PosS3.xml");
        }
        private static void GenerarGrafcetPosS4(int estacion)
        {
            XmlDocument XmlFB = new XmlDocument();

            if (estacion == 0)
            {
                XmlFB.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_PosS4sinEstacionS4.xml");
            }

            if (estacion == 1)
            {
                XmlFB.Load(path + "\\PlantillasXML\\Programas PLC\\GCG_PosS4conEstacionS4.xml");
            }

            XmlFB = CambiarNombreFB(XmlFB, "GCG_PosS4");

            XmlFB.Save(path + "\\Programas\\PLC\\ProgramBlocks\\CG Celula\\FBs\\GCG_PosS4.xml");
            //XmlFB.Save("F:\\TFM\\ImportarXML\\GCG_PosS4.xml");
        }
        #endregion


        #region Modificar tablas de variables HMI del Control General
        public static void ModificarTablasVariablesHMI(int[] estaciones)
        {
            DirectoryInfo root = new DirectoryInfo(path + "\\PlantillasXML\\Variables HMI");
            FileInfo[] files = root.GetFiles("*.*");

            foreach(FileInfo file in files)
            {
                XmlDocument XmlDoc = new XmlDocument();
                XmlDoc.Load(file.FullName);

                XmlNode NodoPrincipal = XmlDoc.DocumentElement.SelectSingleNode("//Document//Hmi.Tag.TagTable//ObjectList");
                XmlNodeList NodosABorrar = XmlDoc.SelectNodes("//*[name(.)='Hmi.Tag.Tag']");

                foreach(XmlNode NodoABorrar in NodosABorrar)
                {
                    if (NodoABorrar.SelectSingleNode("descendant::*[name(.)='ControllerTag']").FirstChild.InnerText.Contains("S1_Ubicacion Base") && estaciones[0] == 0)
                    {
                        // Borramos las variables correspondientes a la estación S1
                        NodoPrincipal.RemoveChild(NodoABorrar);
                    }

                    if (NodoABorrar.SelectSingleNode("descendant::*[name(.)='ControllerTag']").FirstChild.InnerText.Contains("S2_Robot") && estaciones[1] == 0)
                    {
                        // Borramos las variables correspondientes a la estación S2
                        NodoPrincipal.RemoveChild(NodoABorrar);
                    }

                    if (NodoABorrar.SelectSingleNode("descendant::*[name(.)='ControllerTag']").FirstChild.InnerText.Contains("S3_Ubicacion Tapa") && estaciones[2] == 0)
                    {
                        // Borramos las variables correspondientes a la estación S3
                        NodoPrincipal.RemoveChild(NodoABorrar);
                    }

                    if (NodoABorrar.SelectSingleNode("descendant::*[name(.)='ControllerTag']").FirstChild.InnerText.Contains("S4_Almacen") && estaciones[3] == 0)
                    {
                        // Borramos las variables correspondientes a la estación S4
                        NodoPrincipal.RemoveChild(NodoABorrar);
                    }

                    if (NodoABorrar.SelectSingleNode("descendant::*[name(.)='ControllerTag']").FirstChild.InnerText.Contains("ST_Sistema Transporte") && estaciones[4] == 0)
                    {
                        // Borramos las variables correspondientes a la estación ST
                        NodoPrincipal.RemoveChild(NodoABorrar);
                    }
                }

                // Guardamos el documento XML Final
                XmlDoc.Save(path + "\\Programas\\HMI\\TagTables\\Control General\\" + file);
            }
        }
        #endregion
    }
}
