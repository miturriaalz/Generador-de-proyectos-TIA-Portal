﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using GeneradorProyectosTIA.MétodosXML;

namespace GeneradorProyectosTIA
{
    class Program
    {
        public static string path { get; set; }

        [STAThread] // Para poder abrir la ventana para seleccionar el directorio mientras que el formulario está abierto
        static void Main(string[] args)
        {
            using (Inicio ventanaInicio = new Inicio())
            ventanaInicio.ShowDialog();
        }
    }
}
