﻿
namespace GeneradorProyectosTIA
{
    partial class Inicio
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Inicio));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_Crear_proyecto = new System.Windows.Forms.Button();
            this.directorySearcher1 = new System.DirectoryServices.DirectorySearcher();
            this.btn_Salir = new System.Windows.Forms.Button();
            this.TextBox_NombreProyecto = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.TextBox_PathProyecto = new System.Windows.Forms.TextBox();
            this.btn_Path = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Seleccion_Almacen = new System.Windows.Forms.CheckedListBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.TablaServicios = new System.Windows.Forms.DataGridView();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TablaServicios)).BeginInit();
            this.SuspendLayout();
            // 
            // btn_Crear_proyecto
            // 
            this.btn_Crear_proyecto.Location = new System.Drawing.Point(292, 399);
            this.btn_Crear_proyecto.Name = "btn_Crear_proyecto";
            this.btn_Crear_proyecto.Size = new System.Drawing.Size(130, 40);
            this.btn_Crear_proyecto.TabIndex = 0;
            this.btn_Crear_proyecto.Text = "Crear proyecto";
            this.btn_Crear_proyecto.UseVisualStyleBackColor = true;
            this.btn_Crear_proyecto.Click += new System.EventHandler(this.Crear_proyecto_Click);
            // 
            // directorySearcher1
            // 
            this.directorySearcher1.ClientTimeout = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerPageTimeLimit = System.TimeSpan.Parse("-00:00:01");
            this.directorySearcher1.ServerTimeLimit = System.TimeSpan.Parse("-00:00:01");
            // 
            // btn_Salir
            // 
            this.btn_Salir.Location = new System.Drawing.Point(564, 399);
            this.btn_Salir.Name = "btn_Salir";
            this.btn_Salir.Size = new System.Drawing.Size(130, 40);
            this.btn_Salir.TabIndex = 6;
            this.btn_Salir.Text = "Salir";
            this.btn_Salir.UseVisualStyleBackColor = true;
            this.btn_Salir.Click += new System.EventHandler(this.btn_Salir_Click);
            // 
            // TextBox_NombreProyecto
            // 
            this.TextBox_NombreProyecto.Location = new System.Drawing.Point(45, 87);
            this.TextBox_NombreProyecto.Name = "TextBox_NombreProyecto";
            this.TextBox_NombreProyecto.Size = new System.Drawing.Size(345, 20);
            this.TextBox_NombreProyecto.TabIndex = 1;
            this.TextBox_NombreProyecto.TextChanged += new System.EventHandler(this.TextBox_NombreProyecto_TextChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(45, 68);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(105, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "Nombre del proyecto";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(45, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(113, 13);
            this.label2.TabIndex = 3;
            this.label2.Text = "Directorio del proyecto";
            // 
            // TextBox_PathProyecto
            // 
            this.TextBox_PathProyecto.Location = new System.Drawing.Point(48, 136);
            this.TextBox_PathProyecto.Name = "TextBox_PathProyecto";
            this.TextBox_PathProyecto.Size = new System.Drawing.Size(342, 20);
            this.TextBox_PathProyecto.TabIndex = 4;
            this.TextBox_PathProyecto.TextChanged += new System.EventHandler(this.TextBox_PathProyecto_TextChanged);
            // 
            // btn_Path
            // 
            this.btn_Path.Location = new System.Drawing.Point(396, 135);
            this.btn_Path.Name = "btn_Path";
            this.btn_Path.Size = new System.Drawing.Size(26, 22);
            this.btn_Path.TabIndex = 5;
            this.btn_Path.Text = "...";
            this.btn_Path.UseVisualStyleBackColor = true;
            this.btn_Path.Click += new System.EventHandler(this.btn_Path_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(42, 33);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(160, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "Datos del proyecto";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(47, 186);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(177, 20);
            this.label5.TabIndex = 10;
            this.label5.Text = "Selección de servicio";
            // 
            // Seleccion_Almacen
            // 
            this.Seleccion_Almacen.BackColor = System.Drawing.SystemColors.Control;
            this.Seleccion_Almacen.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.Seleccion_Almacen.CheckOnClick = true;
            this.Seleccion_Almacen.FormattingEnabled = true;
            this.Seleccion_Almacen.Items.AddRange(new object[] {
            "Añadir almacén para guardar los productos finalizados."});
            this.Seleccion_Almacen.Location = new System.Drawing.Point(51, 363);
            this.Seleccion_Almacen.Name = "Seleccion_Almacen";
            this.Seleccion_Almacen.Size = new System.Drawing.Size(293, 15);
            this.Seleccion_Almacen.TabIndex = 11;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(564, 68);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(124, 289);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 12;
            this.pictureBox1.TabStop = false;
            // 
            // TablaServicios
            // 
            this.TablaServicios.AllowUserToAddRows = false;
            this.TablaServicios.AllowUserToDeleteRows = false;
            this.TablaServicios.AllowUserToResizeColumns = false;
            this.TablaServicios.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.ControlLight;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.TablaServicios.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.TablaServicios.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.TablaServicios.DefaultCellStyle = dataGridViewCellStyle2;
            this.TablaServicios.Location = new System.Drawing.Point(51, 223);
            this.TablaServicios.MultiSelect = false;
            this.TablaServicios.Name = "TablaServicios";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.TablaServicios.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.TablaServicios.RowHeadersVisible = false;
            this.TablaServicios.RowTemplate.Height = 25;
            this.TablaServicios.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.CellSelect;
            this.TablaServicios.Size = new System.Drawing.Size(453, 134);
            this.TablaServicios.TabIndex = 13;
            this.TablaServicios.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.TablaServicios_CellContentClick);
            // 
            // Inicio
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(742, 461);
            this.Controls.Add(this.TablaServicios);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.Seleccion_Almacen);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.btn_Salir);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.btn_Crear_proyecto);
            this.Controls.Add(this.btn_Path);
            this.Controls.Add(this.TextBox_PathProyecto);
            this.Controls.Add(this.TextBox_NombreProyecto);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "Inicio";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Generador de proyectos de TIA Portal";
            this.Load += new System.EventHandler(this.Inicio_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TablaServicios)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Crear_proyecto;
        private System.DirectoryServices.DirectorySearcher directorySearcher1;
        private System.Windows.Forms.Button btn_Salir;
        private System.Windows.Forms.TextBox TextBox_NombreProyecto;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox TextBox_PathProyecto;
        private System.Windows.Forms.Button btn_Path;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.CheckedListBox Seleccion_Almacen;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.DataGridView TablaServicios;
    }
}