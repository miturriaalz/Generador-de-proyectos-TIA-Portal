﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GeneradorProyectosTIA.MétodosXML;
using GeneradorProyectosTIA.MétodosOpenness;
using System.IO;

// Librerías sugeridas por el manual de TIA Portal Openness
using Siemens.Engineering;
using Siemens.Engineering.Cax;
using Siemens.Engineering.Compiler;
using Siemens.Engineering.Compare;
using Siemens.Engineering.Download;
using Siemens.Engineering.Hmi;
using Siemens.Engineering.Hmi.Cycle;
using Siemens.Engineering.Hmi.Communication;
using Siemens.Engineering.Hmi.Globalization;
using Siemens.Engineering.Hmi.RuntimeScripting;
using Siemens.Engineering.Hmi.Screen;
using Siemens.Engineering.Hmi.Tag;
using Siemens.Engineering.Hmi.TextGraphicList;
using Siemens.Engineering.HW;
using Siemens.Engineering.HW.Extensions;
using Siemens.Engineering.HW.Features;
using Siemens.Engineering.HW.Utilities;
using Siemens.Engineering.Library;
using Siemens.Engineering.Library.MasterCopies;
using Siemens.Engineering.Library.Types;
using Siemens.Engineering.SW;
using Siemens.Engineering.SW.Blocks;
using Siemens.Engineering.SW.ExternalSources;
using Siemens.Engineering.SW.Tags;
using Siemens.Engineering.SW.TechnologicalObjects;
using Siemens.Engineering.SW.TechnologicalObjects.Motion;
using Siemens.Engineering.SW.Types;
using Siemens.Engineering.Upload;

namespace GeneradorProyectosTIA
{
    public partial class Inicio : Form
    {
        public Inicio()
        {
            InitializeComponent();
        }

        private void Inicio_Load(object sender, EventArgs e)
        {
            btn_Crear_proyecto.Enabled = false;

            // Comprobar que el usuario dispone de la versión V17 de TIA Portal. En caso de no disponer de ella cerrar la aplicación.
            bool existeTIAV17 = MetodosOpenness.MyResolver();

            if (existeTIAV17 == false)
            {
                // Mostrar PopUp que avisa que no tiene la versión V17 de TIA Portal
                string mensaje = "No dispone de la versión V17 de TIA Portal o no está instalada en el directorio por defecto: \"C:\\Program Files\\Siemens\\Automation\\Portal V17\\PublicAPI\\V17\". La aplicación se cerrará.";

                MessageBoxButtons buttons = MessageBoxButtons.OK;
                MessageBox.Show(this, mensaje, "Error versión TIA portal", buttons, MessageBoxIcon.Error);
                // Cerrar la aplicación 
                Application.Exit();
            }


            #region Crear tabla de selección de montaje
            // Agregar columnas
            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            checkBoxColumn.Name = "Selección de tipo de servicio";
            checkBoxColumn.HeaderText = "Selección de tipo de servicio";
            checkBoxColumn.TrueValue = true;
            checkBoxColumn.FalseValue = false;
            checkBoxColumn.ReadOnly = false;
            checkBoxColumn.Resizable = DataGridViewTriState.False;
            checkBoxColumn.Width = 80;

            DataGridViewTextBoxColumn textBoxColumn1 = new DataGridViewTextBoxColumn();
            textBoxColumn1.Name = "Material de entrada";
            textBoxColumn1.HeaderText = "Material de entrada";
            textBoxColumn1.ReadOnly = true;
            textBoxColumn1.Resizable = DataGridViewTriState.False;
            textBoxColumn1.Width = 170;

            DataGridViewTextBoxColumn textBoxColumn2 = new DataGridViewTextBoxColumn();
            textBoxColumn2.Name = "Montajes requeridos";
            textBoxColumn2.HeaderText = "Montajes requeridos";
            textBoxColumn2.ReadOnly = true;
            textBoxColumn2.Resizable = DataGridViewTriState.False;
            textBoxColumn2.Width = 200;

            TablaServicios.Columns.Add(checkBoxColumn);
            TablaServicios.Columns.Add(textBoxColumn1);
            TablaServicios.Columns.Add(textBoxColumn2);

            // Agregar filas
            DataGridViewRow row1 = new DataGridViewRow();
            row1.CreateCells(TablaServicios);
            row1.Cells[1].Value = "-";
            row1.Cells[2].Value = "Base + Eje + Rodamiento + Tapa";

            DataGridViewRow row2 = new DataGridViewRow();
            row2.CreateCells(TablaServicios);
            row2.Cells[1].Value = "Base";
            row2.Cells[2].Value = "Eje + Rodamiento + Tapa";

            DataGridViewRow row3 = new DataGridViewRow();
            row3.CreateCells(TablaServicios);
            row3.Cells[1].Value = "Base + Eje";
            row3.Cells[2].Value = "Rodamiento + Tapa";

            DataGridViewRow row4 = new DataGridViewRow();
            row4.CreateCells(TablaServicios);
            row4.Cells[1].Value = "Base + Eje + Rodamiento";
            row4.Cells[2].Value = "Tapa";

            TablaServicios.Rows.Add(row1);
            TablaServicios.Rows.Add(row2);
            TablaServicios.Rows.Add(row3);
            TablaServicios.Rows.Add(row4);
            #endregion
        }
        private void Crear_proyecto_Click(object sender, EventArgs e)
        {
            btn_Crear_proyecto.Enabled = false;
            btn_Salir.Enabled = false;

            string nombreProyecto = TextBox_NombreProyecto.Text;
            string pathProyecto = TextBox_PathProyecto.Text;

            string mensaje;
            MessageBoxButtons buttons;

            if (!Directory.Exists(pathProyecto))
            {
                // Si el directorio del proyecto no existe sale un mensaje avisando y sale de esta función (Crear_proyecto_Click).
                mensaje = "El directorio que ha seleccionado para el proyecto no existe o no es válido.";
                buttons = MessageBoxButtons.OK;
                MessageBox.Show(this, mensaje, "Directorio del proyecto", buttons, MessageBoxIcon.Error);
                return;
            }

            #region Estaciones a añadir
            int[] estaciones = { 0, 0, 0, 0, 0 }; // Array que guarda las estaciones que quiere el usuario. (S1, S2, S3, S4, ST)

            int indice = 0;

            foreach(DataGridViewRow row in TablaServicios.Rows)
            {
                bool isChecked = Convert.ToBoolean(row.Cells[0].Value);

                if(isChecked)
                {
                    indice = row.Index;
                }
            }

            switch (indice)
            {
                case 0:
                    estaciones[0] = 1;
                    estaciones[1] = 2; // Cuando vale 2 significa que la estación S2 montará tanto el eje como el rodamiento
                    estaciones[2] = 1;
                    estaciones[3] = 0;
                    estaciones[4] = 1;
                    break;
                case 1:
                    estaciones[0] = 0;
                    estaciones[1] = 2;
                    estaciones[2] = 1;
                    estaciones[3] = 0;
                    estaciones[4] = 1;
                    break;
                case 2:
                    estaciones[0] = 0;
                    estaciones[1] = 1;  // Cuando vale 1 significa que la estación S2 sólo montará el rodamiento
                    estaciones[2] = 1;
                    estaciones[3] = 0;
                    estaciones[4] = 1;
                    break;
                case 3:
                    estaciones[0] = 0;
                    estaciones[1] = 0;
                    estaciones[2] = 1;
                    estaciones[3] = 0;
                    estaciones[4] = 1;
                    break;
                default:
                    break;
            }

            if(Seleccion_Almacen.CheckedIndices.Count == 1)
            {
                estaciones[3] = 1;
            }

            #endregion Estaciones a añadir

            #region Modificar ficheros XMLs

            // Generamos el grafcet de Condiciones Iniciales
            ModificarXML.GenerarGrafcetCondIni(estaciones);

            // Generamos el grafcet de Marcha de Preparación
            ModificarXML.GenerarGrafcetMarchaPre(estaciones);

            // Generamos el grafcet de Producción Normal
            ModificarXML.GenerarGrafcetProdNorm(estaciones);

            // Generamos el grafcet de Emergencia
            ModificarXML.GenerarGrafcetEmergencia(estaciones);

            // Generamos los grafcets de posiciones (PosS1, PosS2, PosS3, PosS4)
            ModificarXML.GenerarGrafcetsPos(estaciones);

            // Instanciamos las estaciones seleccionadas en el OB1
            ModificarXML.GenerarProgramaOB1(estaciones);

            // Modificamos las tablas de variables HMI
            ModificarXML.ModificarTablasVariablesHMI(estaciones);

            #endregion Modificar ficheros XMLs

            #region Crear proyecto TIA Portal e importar ficheros XML

            // Path de la solución de VisualStudio
            string path = Directory.GetCurrentDirectory(); // Devuelve el directorio configurado en las propiedades del proyecto. Al principio era \bin\Debug pero lo he cambiado a \GeneradorProyectosTIA

            // Path de la plantilla del proyecto de TIA Portal
            string pathProyectoPlantilla = path + "\\PlantillaProyecto\\CG Jerarquico - S1 - ST - S3 CG Jerarquico - S1 - ST - S3 Plantilla.zap17";

            using (TiaPortal tiaPortal = new TiaPortal(TiaPortalMode.WithUserInterface))
            {
                // Creamos el proyecto con los datos introducidos por el usuario
                Project nuevoProyecto = MetodosOpenness.CrearProyectoPlantilla(tiaPortal, pathProyectoPlantilla, pathProyecto, nombreProyecto);

                #region Importar PLC
                PlcSoftware plcTarget = MetodosOpenness.GetPLCTargetByName(nuevoProyecto.Devices, "MAESTRO");

                // Importar Bloques de Programa PLC
                MetodosOpenness.ImportProgramBlocks(plcTarget, estaciones);

                // Importar Tablas de Variables PLC
                MetodosOpenness.ImportPLCTagTables(plcTarget, estaciones);
                #endregion

                #region Importar HMI
                HmiTarget hmiTarget = MetodosOpenness.GetFirstHMITarget(nuevoProyecto.Devices);

                // Importar plantilla HMI
                MetodosOpenness.ImportScreenTemplatesToHMITarget(hmiTarget);

                // Importar pantallas HMI
                MetodosOpenness.ImportHMIScreens(hmiTarget, estaciones);

                // Importar tablas de variables HMI
                MetodosOpenness.ImportHMITagTables(hmiTarget, estaciones);
                #endregion

                // BORRAR LOS DISPOSITIVOS QUE NO SE NECESITAN
                MetodosOpenness.DeleteHWDevices(nuevoProyecto, estaciones);

                // Compilar PLC y HMI
                MetodosOpenness.CompilePlcSoftware(plcTarget);
                MetodosOpenness.CompileHmiTarget(hmiTarget);

                // Guardar cambios
                nuevoProyecto.Save();
            }

            // Borrar el proyecto plantilla desarchivado de la carpeta del proyecto
            DirectoryInfo DirectorioProyecto = new DirectoryInfo(pathProyecto + "\\" + nombreProyecto);
            DirectoryInfo[] proyectos = DirectorioProyecto.GetDirectories();

            foreach (DirectoryInfo proyecto in proyectos)
            {
                if(proyecto.Name == "CG Jerarquico - S1 - ST - S3 - 02-02-2024_V17")
                {
                    proyecto.Delete(true);
                }
            }

            #endregion Crear proyecto TIA Portal e importar ficheros XML

            // Mostrar mensaje de que el proyecto se ha creado
            mensaje = "El proyecto se ha creado correctamente.";
            buttons = MessageBoxButtons.OK;
            MessageBox.Show(this, mensaje, "Proyecto creado", buttons, MessageBoxIcon.Information);
            btn_Salir.Enabled = true;
            return;
        }

        private void btn_Path_Click(object sender, EventArgs e)
        {
            try
            {
                FolderBrowserDialog _folderBrowserDialog = new FolderBrowserDialog();
                var resultado = _folderBrowserDialog.ShowDialog();
                if (resultado == DialogResult.OK)
                {
                    TextBox_PathProyecto.Text = _folderBrowserDialog.SelectedPath;
                }
            }
            catch (Exception exception)
            {
                MessageBox.Show(exception.Message, "Exception", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_Salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void TextBox_NombreProyecto_TextChanged(object sender, EventArgs e)
        {
            habilitarBtnCrearProyecto();
        }

        private void TextBox_PathProyecto_TextChanged(object sender, EventArgs e)
        {
            habilitarBtnCrearProyecto();
        }

        private void habilitarBtnCrearProyecto()
        {
            bool anyChecked = false;

            foreach (DataGridViewRow row in TablaServicios.Rows)
            {
                if (Convert.ToBoolean(row.Cells[0].Value))
                {
                    anyChecked = true;
                    break;
                }
            }

            if (anyChecked && !string.IsNullOrWhiteSpace(TextBox_NombreProyecto.Text) && !string.IsNullOrWhiteSpace(TextBox_PathProyecto.Text))
            {
                btn_Crear_proyecto.Enabled = true;
            }
            else
            {
                btn_Crear_proyecto.Enabled = false;
            }
        }

        private void TablaServicios_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewSelectedCellCollection coleccion = TablaServicios.SelectedCells;
            if (coleccion[0].ColumnIndex == 0)
            {
                int indice = coleccion[0].RowIndex;

                foreach (DataGridViewRow row in TablaServicios.Rows)
                {
                    if (row.Index == indice)
                    {
                        // Si la fila contiene la celda seleccionada se comprueba si el checkbox de esa fila está seleccionado o no. 
                        bool isChecked = Convert.ToBoolean(row.Cells[0].Value);

                        if (isChecked)
                        {
                            // Si el checkbox está checked, se pone unchecked
                            row.Cells[0].Value = false;
                        }
                        else
                        {
                            // Si el checkbox está unchecked, se pone checked
                            row.Cells[0].Value = true;
                        }

                    }

                    else
                    {
                        // Si la fila no contiene la celda seleccionada, el checkbox de esa fila se pone unchecked.
                        row.Cells[0].Value = false;
                    }
                    if (row.Index != indice)
                    {
                        row.Cells[0].Value = false;
                    }

                }
            }

            habilitarBtnCrearProyecto();
        }
    }
}
