﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Siemens.Engineering;
using Siemens.Engineering.HW;
using Siemens.Engineering.HW.Features;
using Siemens.Engineering.SW;
using Siemens.Engineering.SW.Blocks;
using Siemens.Engineering.SW.Units;
using System.IO;
using System.Reflection;

// Librerías sugeridas por el manual de TIA Portal Openness
using System;
using System.Collections.Generic;
using System.IO;
using Siemens.Engineering;
using Siemens.Engineering.Cax;
using Siemens.Engineering.Compiler;
using Siemens.Engineering.Compare;
using Siemens.Engineering.Download;
using Siemens.Engineering.Hmi;
using Siemens.Engineering.Hmi.Cycle;
using Siemens.Engineering.Hmi.Communication;
using Siemens.Engineering.Hmi.Globalization;
using Siemens.Engineering.Hmi.RuntimeScripting;
using Siemens.Engineering.Hmi.Screen;
using Siemens.Engineering.Hmi.Tag;
using Siemens.Engineering.Hmi.TextGraphicList;
using Siemens.Engineering.HW;
using Siemens.Engineering.HW.Extensions;
using Siemens.Engineering.HW.Features;
using Siemens.Engineering.HW.Utilities;
using Siemens.Engineering.Library;
using Siemens.Engineering.Library.MasterCopies;
using Siemens.Engineering.Library.Types;
using Siemens.Engineering.SW;
using Siemens.Engineering.SW.Blocks;
using Siemens.Engineering.SW.ExternalSources;
using Siemens.Engineering.SW.Tags;
using Siemens.Engineering.SW.TechnologicalObjects;
using Siemens.Engineering.SW.TechnologicalObjects.Motion;
using Siemens.Engineering.SW.Types;
using Siemens.Engineering.Upload;

namespace GeneradorProyectosTIA.MétodosOpenness
{
    class MetodosOpenness
    {
        // Verificar si TIA Portal V17 está instalado
        public static bool MyResolver()
        {
            string name = "Siemens.Engineering.dll";
            // Edit the following path according to your installed version of TIA Portal
            string path = Path.Combine(@"C:\Program Files\Siemens\Automation\Portal V17\PublicAPI\V17\" + name);
            string fullPath = Path.GetFullPath(path);
            if (File.Exists(fullPath))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // Seleccionar el PLC por nombre
        public static PlcSoftware GetPLCTargetByName(DeviceComposition devices, string DeviceName)
        {
            Software softwareBase;
            PlcSoftware plcSoftware = null;

            foreach (Device device in devices)
            {
                DeviceItemComposition deviceItemComposition = device.DeviceItems;
                foreach (DeviceItem deviceItem in deviceItemComposition)
                {
                    if (deviceItem.Name == DeviceName)
                    {
                        SoftwareContainer softwareContainer = deviceItem.GetService<SoftwareContainer>();
                        softwareBase = softwareContainer.Software;
                        plcSoftware = softwareBase as PlcSoftware;
                    }
                }
            }
            return plcSoftware;
        }

        // Seleccionar el primer HMI
        public static HmiTarget GetFirstHMITarget(DeviceComposition devices)
        {
            HmiTarget hmiTarget = null;

            foreach (Device device in devices)
            {
                DeviceItemComposition deviceItemComposition = device.DeviceItems;
                foreach (DeviceItem deviceItem in deviceItemComposition)
                {
                        DeviceItem deviceItemToGetService = deviceItem as DeviceItem;
                        SoftwareContainer container = deviceItemToGetService.GetService<SoftwareContainer>();
                        if(container != null)
                        {
                            hmiTarget = container.Software as HmiTarget;
                        }
                }
            }
            return hmiTarget;
        }

        // Compilar PLC
        public static void CompilePlcSoftware(PlcSoftware plcSoftware)
        {
            ICompilable compileService = plcSoftware.GetService<ICompilable>();
            CompilerResult result = compileService.Compile();
        }

        // Compilar HMI
        public static void CompileHmiTarget(HmiTarget hmiTarget)
        {
            ICompilable compileService = hmiTarget.GetService<ICompilable>();
            CompilerResult result = compileService.Compile();
        }

        // Borrar los dispositivos hardware que no sean necesarios
        public static void DeleteHWDevices(Project proyecto, int[] estaciones)
        {
            List<Device> lista = new List<Device>();

            DeviceComposition devices = proyecto.UngroupedDevicesGroup.Devices;

            foreach(Device device in devices)
            {
                foreach(DeviceItem item in device.DeviceItems)
                {
                    if(item.Name == "s1_io_estacion" && estaciones[0] == 0)
                    {
                        // Guardamos en la lista el dispositivo que tenga un objeto llamado "s1_io_estacion". Este dispositivo es la estación S1.
                        lista.Add(device);
                    }
                    if (item.Name == "s2_io_Estacion" && estaciones[1] == 0)
                    {
                        lista.Add(device);
                    }
                    if (item.Name == "s3_io_Estacion" && estaciones[2] == 0)
                    {
                        lista.Add(device);
                    }
                    if (item.Name == "s4_io_Estacion" && estaciones[3] == 0)
                    {
                        lista.Add(device);
                    }
                }
            }

            // Borrar los dispositivos guardados en la lista
            foreach(Device deviceToDelete in lista)
            {
                deviceToDelete.Delete();
            }
        }

        // Crear proyecto a partir de proyecto plantilla
        public static Project CrearProyectoPlantilla(TiaPortal tiaPortal, string pathProyectoPlantilla, string pathProyectoNuevo, string nombreProyecto)
        {
            // Creamos una nueva carpeta en "pathProyectoNuevo" con el nombre "nombreProyecto"
            string pathCarpetaProyecto = Directory.CreateDirectory(pathProyectoNuevo + "\\" + nombreProyecto).FullName;

            // Desarchivamos el proyecto plantilla que se encuentra en "pathProyectoPlantilla" y lo guardamos en "pathCarpetaProyecto"
            ProjectComposition proyectos = tiaPortal.Projects;
            proyectos.Retrieve(new FileInfo(pathProyectoPlantilla), new DirectoryInfo(pathCarpetaProyecto));
            Project nuevoProyecto = proyectos[0];

            // Guardamos el proyecto con el directorio y nombre deseado
            nuevoProyecto.SaveAs(new DirectoryInfo(pathCarpetaProyecto + "\\" + nombreProyecto));
            return nuevoProyecto;
        }

        // Crear carpetas de grupos en ProgramBlocks
        public static PlcBlockUserGroup CreatePlcBlockGroup(PlcSoftware plcSoftware, string nombreGrupo)
        {
            PlcBlockGroup blockGroup = plcSoftware.BlockGroup;
            PlcBlockUserGroup grupo = blockGroup.Groups.Create(nombreGrupo);
            return grupo;
        }

        // Crear subcarpetas dentro de los grupos de ProgramBlocks
        public static PlcBlockUserGroup CreatePlcBlockSubgroup(PlcBlockGroup grupoPadre, string nombreSubgrupo)
        {
            PlcBlockUserGroup subGrupo = grupoPadre.Groups.Create(nombreSubgrupo);
            return subGrupo;
        }

        //Importar bloques
        public static void ImportBlocks(PlcSoftware plcSoftware, FileInfo[] files, PlcBlockGroup grupo)
        {
            PlcBlockGroup blockGroup = plcSoftware.BlockGroup;

            if(grupo == null)
            {
                // Si el nombre del grupo es nulo importamos los programas directamente en ProgramBlocks.
                foreach (FileInfo file in files)
                {
                    IList<PlcBlock> blocks = blockGroup.Blocks.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
            }

            else
            {
                // Importamos los programas al grupo especificado.
                foreach (FileInfo file in files)
                {
                    grupo.Blocks.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
            }
        }

        //Importar bloques de sistema PLC
        public static void ImportSystemBlocks(PlcSoftware plcSoftware, FileInfo[] files)
        {
            //PlcBlockSystemGroup systemblockGroup = plcSoftware.BlockGroup;
            PlcSystemBlockGroupComposition systemblockGroup = plcSoftware.BlockGroup.SystemBlockGroups;
            foreach (FileInfo file in files)
            {
                systemblockGroup[0].Groups.Find("Program resources").Blocks.Import(new FileInfo(file.FullName), ImportOptions.Override);
            }
        }

        // Importar Bloques de Programa PLC
        public static void ImportProgramBlocks(PlcSoftware plcSoftware, int[] estaciones)
        {
            string DirectorioActual = Directory.GetCurrentDirectory();

            #region Importar bloques de CG_Célula
            PlcBlockGroup grupo = CreatePlcBlockGroup(plcSoftware, "CG_Celula");
            // Importar FBs
            DirectoryInfo root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\CG Celula\\FBs");
            FileInfo[] files = root.GetFiles(".");
            ImportBlocks(plcSoftware, files, grupo);
            // Importar DBs
            root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\CG Celula\\DBs");
            files = root.GetFiles(".");
            ImportBlocks(plcSoftware, files, grupo);
            // Creamos los DBss de instancia de los FBs que se han modificado (CondIni, MarchaPre, ProdNorm, Emergencia, PosS1...)
            CreateInstanceDBs(plcSoftware, grupo);
            #endregion

            #region Importar Gemelo Funcional del Planificador
            grupo = CreatePlcBlockGroup(plcSoftware, "S1 - S2 - S3 - S5 - ST  - Gemelo Funcional PSE (Peticiones Servicios Enventos)");
            root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Gemelos Funcionales\\Planificador\\FBs");
            files = root.GetFiles(".");
            ImportBlocks(plcSoftware, files, grupo);

            root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Gemelos Funcionales\\Planificador\\DBs");
            files = root.GetFiles(".");
            ImportBlocks(plcSoftware, files, grupo);
            #endregion

            if (estaciones[0] > 0)
            {
                #region Importar bloques de S1 Ubicación Base
                grupo = CreatePlcBlockGroup(plcSoftware, "S1-Ubicación Base");
                // Importar FBs
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S1 Ubicacion Base\\FBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);
                // Importar DBs
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S1 Ubicacion Base\\DBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);

                PlcBlockGroup subgrupo = CreatePlcBlockSubgroup(grupo, "GFB S1");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S1 Ubicacion Base\\GFB S1\\FBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, subgrupo);

                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S1 Ubicacion Base\\GFB S1\\DBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, subgrupo);

                grupo = plcSoftware.BlockGroup.Groups.Find("S1 - S2 - S3 - S5 - ST  - Gemelo Funcional PSE (Peticiones Servicios Enventos)");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Gemelos Funcionales\\S1 Ubicacion Base\\FBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);

                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Gemelos Funcionales\\S1 Ubicacion Base\\DBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);
                #endregion
            }

            if (estaciones[1] > 0)
            {
                #region Importar bloques de S2 Robot
                //grupo = CreatePlcBlockGroup(plcSoftware, "S2-Robot");
                //root = new DirectoryInfo("DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S2 Robot\\FBs");
                //files = root.GetFiles(".");
                //ImportBlocks(plcSoftware, files, grupo);

                //root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S2 Robot\\DBs");
                //files = root.GetFiles(".");
                //ImportBlocks(plcSoftware, files, grupo);

                //PlcBlockGroup subgrupo = CreatePlcBlockSubgroup(grupo, "GFB S2");
                //root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S2 Robot\\GFB S2\\FBs");
                //files = root.GetFiles(".");
                //ImportBlocks(plcSoftware, files, subgrupo);

                //root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S2 Robot\\GFB S2\\DBs");
                //files = root.GetFiles(".");
                //ImportBlocks(plcSoftware, files, subgrupo);

                grupo = plcSoftware.BlockGroup.Groups.Find("S1 - S2 - S3 - S5 - ST  - Gemelo Funcional PSE (Peticiones Servicios Enventos)");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Gemelos Funcionales\\S2 Robot\\FBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);

                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Gemelos Funcionales\\S2 Robot\\DBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);
                #endregion
            }

            if (estaciones[2] > 0)
            {
                #region Importar bloques de S3 Ubicación Tapa
                grupo = CreatePlcBlockGroup(plcSoftware, "S3-Ubicación Tapa");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S3 Ubicacion Tapa\\FBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);

                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S3 Ubicacion Tapa\\DBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);

                PlcBlockGroup subgrupo = CreatePlcBlockSubgroup(grupo, "GFB S3");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S3 Ubicacion Tapa\\GFB S3\\FBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, subgrupo);

                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S3 Ubicacion Tapa\\GFB S3\\DBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, subgrupo);

                grupo = plcSoftware.BlockGroup.Groups.Find("S1 - S2 - S3 - S5 - ST  - Gemelo Funcional PSE (Peticiones Servicios Enventos)");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Gemelos Funcionales\\S3 Ubicacion Tapa\\FBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);

                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Gemelos Funcionales\\S3 Ubicacion Tapa\\DBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);

                #endregion
            }

            if (estaciones[3] > 0)
            {
                #region Importar bloques de S4 Almacén
                //grupo = CreatePlcBlockGroup(plcSoftware, "S4-Almacén");
                //root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S4 Almacen\\FBs");
                //files = root.GetFiles(".");
                //ImportBlocks(plcSoftware, files, grupo);

                //grupo = CreatePlcBlockGroup(plcSoftware, "S4-Almacén");
                //root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S4 Almacen\\DBs");
                //files = root.GetFiles(".");
                //ImportBlocks(plcSoftware, files, grupo);

                //PlcBlockGroup subgrupo = CreatePlcBlockSubgroup(grupo, "GFB S4");
                //root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S4 Almacen\\GFB S4\\FBs");
                //files = root.GetFiles(".");
                //ImportBlocks(plcSoftware, files, subgrupo);

                //root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\S4 Almacen\\GFB S4\\DBs");
                //files = root.GetFiles(".");
                //ImportBlocks(plcSoftware, files, subgrupo);

                grupo = plcSoftware.BlockGroup.Groups.Find("S1 - S2 - S3 - S5 - ST  - Gemelo Funcional PSE (Peticiones Servicios Enventos)");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Gemelos Funcionales\\S4 Almacen\\FBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);

                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Gemelos Funcionales\\S4 Almacen\\DBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);
                #endregion
            }

            if (estaciones[4] > 0)
            {
                #region Importar bloques de ST Sistema Transporte
                grupo = CreatePlcBlockGroup(plcSoftware, "ST-Sistema Transporte");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\ST Sistema Transporte\\FBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);

                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\ST Sistema Transporte\\DBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);

                PlcBlockGroup subgrupo = CreatePlcBlockSubgroup(grupo, "GFB S4");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\ST Sistema Transporte\\GFB ST\\FBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, subgrupo);

                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\ST Sistema Transporte\\GFB ST\\DBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, subgrupo);

                grupo = plcSoftware.BlockGroup.Groups.Find("S1 - S2 - S3 - S5 - ST  - Gemelo Funcional PSE (Peticiones Servicios Enventos)");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Gemelos Funcionales\\ST Sistema Transporte\\FBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);

                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Gemelos Funcionales\\ST Sistema Transporte\\DBs");
                files = root.GetFiles(".");
                ImportBlocks(plcSoftware, files, grupo);
                #endregion
            }

            #region Importar bloque Main y Otros
            root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Otros\\FBs");
            files = root.GetFiles(".");
            ImportBlocks(plcSoftware, files, null);

            root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Otros\\DBs");
            files = root.GetFiles(".");
            ImportBlocks(plcSoftware, files, null);
            #endregion

            #region Importar Bloques de Datos
            grupo = CreatePlcBlockGroup(plcSoftware, "Bloques de Datos");
            root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\ProgramBlocks\\Bloques de Datos");
            files = root.GetFiles(".");
            ImportBlocks(plcSoftware, files, grupo);
            #endregion

            #region Importar Bloques de Sistema
            root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\SystemBlocks");
            files = root.GetFiles(".");
            ImportSystemBlocks(plcSoftware, files);
            #endregion
        }

        // Crear DBs de instancia de los FBs modificados
        public static void CreateInstanceDBs(PlcSoftware plcSoftware, PlcBlockGroup grupo)
        {
            grupo.Blocks.CreateInstanceDB("CG_CondIniciales_DB", true, 6, "GCG_CondIniciales");
            grupo.Blocks.CreateInstanceDB("CG_MarchaPre_DB", true, 6, "GCG_MarchaPre");
            grupo.Blocks.CreateInstanceDB("CG_ActivarProdNorm_DB", true, 6, "GCG_ActivarProdNorm");
            grupo.Blocks.CreateInstanceDB("CG_Emergencia_DB", true, 6, "GCG_Emergencia");
            grupo.Blocks.CreateInstanceDB("CG_PosS1_DB", true, 6, "GCG_PosS1");
            grupo.Blocks.CreateInstanceDB("CG_PosS2_DB", true, 6, "GCG_PosS2");
            grupo.Blocks.CreateInstanceDB("CG_PosS3_DB", true, 6, "GCG_PosS3");
            grupo.Blocks.CreateInstanceDB("CG_PosS4_DB", true, 6, "GCG_PosS4");

        }

        //Importar tablas de variables PLC
        public static void ImportPLCTagTables(PlcSoftware plcSoftware, int[] estaciones)
        {
            string DirectorioActual = Directory.GetCurrentDirectory();

            PlcTagTableSystemGroup plcTagTableSystemGroup = plcSoftware.TagTableGroup;
            PlcTagTableComposition tagTables = plcTagTableSystemGroup.TagTables;

            #region Importar tablas de variables del Control General
            DirectoryInfo root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\TagTables\\Control General");
            FileInfo[] files = root.GetFiles(".");
            plcTagTableSystemGroup.Groups.Create("Control General");
            foreach(FileInfo file in files)
            {
                plcTagTableSystemGroup.Groups.Find("Control General").TagTables.Import(new FileInfo(file.FullName), ImportOptions.Override);
            }
            #endregion

            #region Importar tablas de variables de Monitorización
            root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\TagTables\\Monitorización");
            files = root.GetFiles(".");
            plcTagTableSystemGroup.Groups.Create("Monitorización");
            foreach (FileInfo file in files)
            {
                plcTagTableSystemGroup.Groups.Find("Monitorización").TagTables.Import(new FileInfo(file.FullName), ImportOptions.Override);
            }
            #endregion

            if(estaciones[0] > 0)
            {
                #region Importar tablas de variables de S1 Ubicación Base
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\TagTables\\S1 Ubicacion Base");
                files = root.GetFiles(".");
                plcTagTableSystemGroup.Groups.Create("S1 Ubicación Base");
                foreach (FileInfo file in files)
                {
                    plcTagTableSystemGroup.Groups.Find("S1 Ubicación Base").TagTables.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
                #endregion
            }

            if(estaciones[1] > 0)
            {
                #region Importar tablas de variables de S2 Robot
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\TagTables\\S2 Robot");
                files = root.GetFiles(".");
                plcTagTableSystemGroup.Groups.Create("S2 Robot");
                foreach (FileInfo file in files)
                {
                    plcTagTableSystemGroup.Groups.Find("S2 Robot").TagTables.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
                #endregion
            }

            if (estaciones[2] > 0)
            {
                #region Importar tablas de variables de S3 Ubicación Tapa
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\TagTables\\S3 Ubicacion Tapa");
                files = root.GetFiles(".");
                plcTagTableSystemGroup.Groups.Create("S3 Ubicación Tapa");
                foreach (FileInfo file in files)
                {
                    plcTagTableSystemGroup.Groups.Find("S3 Ubicación Tapa").TagTables.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
                #endregion
            }

            if (estaciones[3] > 0)
            {
                #region Importar tablas de variables de S4 Almacén
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\TagTables\\S4 Almacen");
                files = root.GetFiles(".");
                plcTagTableSystemGroup.Groups.Create("S4 Almacén");
                foreach (FileInfo file in files)
                {
                    plcTagTableSystemGroup.Groups.Find("S4 Almacén").TagTables.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
                #endregion
            }

            if (estaciones[4] > 0)
            {
                #region Importar tablas de variables de ST Sistema de Transporte
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\PLC\\TagTables\\ST Sistema Transporte");
                files = root.GetFiles(".");
                plcTagTableSystemGroup.Groups.Create("ST Sistema Transporte");
                foreach (FileInfo file in files)
                {
                    plcTagTableSystemGroup.Groups.Find("ST Sistema Transporte").TagTables.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
                #endregion
            }
        }


        //Importar plantillas HMI
        public static void ImportScreenTemplatesToHMITarget(HmiTarget hmitarget)
        {
            string DirectorioActual = Directory.GetCurrentDirectory();

            ScreenTemplateSystemFolder folder = hmitarget.ScreenTemplateFolder;
            DirectoryInfo root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\Templates");
            FileInfo[] files = root.GetFiles(".");

            foreach (FileInfo file in files)
            {
                folder.ScreenTemplates.Import(new FileInfo(file.FullName), ImportOptions.Override);
            }
        }

        // Importar pantallas HMI
        public static void ImportHMIScreens(HmiTarget hmitarget, int[] estaciones)
        {
            string DirectorioActual = Directory.GetCurrentDirectory();

            ScreenUserFolder folder;

            // Importamos las pantallas HMI del Control General
            DirectoryInfo root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\Screens\\Control General");
            FileInfo[] files = root.GetFiles(".");
            foreach (FileInfo file in files)
            {
                hmitarget.ScreenFolder.Screens.Import(new FileInfo(file.FullName), ImportOptions.Override);
            }

            if (estaciones[0] > 0)
            {
                // Importamos las pantallas HMI de la estación S1
                folder = hmitarget.ScreenFolder.Folders.Create("S1-Ubicación Base");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\Screens\\S1 Ubicacion Base");
                files = root.GetFiles(".");
                foreach (FileInfo file in files)
                {
                    folder.Screens.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
            }

            //if (estaciones[1] > 0)
            //{
            //    // Importamos las pantallas HMI de la estación S2
            //    folder = hmitarget.ScreenFolder.Folders.Create("S2-Robot");
            //    root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\Screens\\S2 Robot");
            //    files = root.GetFiles(".");
            //    foreach (FileInfo file in files)
            //    {
            //        folder.Screens.Import(new FileInfo(file.FullName), ImportOptions.Override);
            //    }
            //}

            if (estaciones[2] > 0)
            {
                // Importamos las pantallas HMI de la estación S3
                folder = hmitarget.ScreenFolder.Folders.Create("S3-Ubicación Tapa");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\Screens\\S3 Ubicacion Tapa");
                files = root.GetFiles(".");
                foreach (FileInfo file in files)
                {
                    folder.Screens.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
            }

            //if (estaciones[3] > 0)
            //{
            //    // Importamos las pantallas HMI de la estación S4
            //    folder = hmitarget.ScreenFolder.Folders.Create("S4-Almacén");
            //    root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\Screens\\S4 Almacen");
            //    files = root.GetFiles(".");
            //    foreach (FileInfo file in files)
            //    {
            //        folder.Screens.Import(new FileInfo(file.FullName), ImportOptions.Override);
            //    }
            //}

            if (estaciones[4] > 0)
            {
                // Importamos las pantallas HMI de la estación ST
                folder = hmitarget.ScreenFolder.Folders.Create("ST-Sistema Transporte");
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\Screens\\ST Sistema Transporte");
                files = root.GetFiles(".");
                foreach (FileInfo file in files)
                {
                    folder.Screens.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
            }

        }

        // Importar tablas de variables HMI
        public static void ImportHMITagTables(HmiTarget hmitarget, int[] estaciones)
        {
            string DirectorioActual = Directory.GetCurrentDirectory();

            TagSystemFolder folder = hmitarget.TagFolder;
            TagTableComposition tables = folder.TagTables;

            // Importamos las tablas de variables del Control General
            DirectoryInfo root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\TagTables\\Control General");
            FileInfo[] files = root.GetFiles(".");
            foreach (FileInfo file in files)
            {
                tables.Import(new FileInfo(file.FullName), ImportOptions.Override);
            }

            if (estaciones[0] > 0)
            {
                // Importamos las tablas de variables de la estación S1
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\TagTables\\S1 Ubicacion Base");
                files = root.GetFiles(".");
                foreach (FileInfo file in files)
                {
                    tables.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
            }

            //if (estaciones[1] > 0)
            //{
            //    // Importamos las tablas de variables de la estación S2
            //    root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\TagTables\\S2 Robot");
            //    files = root.GetFiles(".");
            //    foreach (FileInfo file in files)
            //    {
            //        tables.Import(new FileInfo(file.FullName), ImportOptions.Override);
            //    }
            //}

            if (estaciones[2] > 0)
            {
                // Importamos las tablas de variables de la estación S3
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\TagTables\\S3 Ubicacion Tapa");
                files = root.GetFiles(".");
                foreach (FileInfo file in files)
                {
                    tables.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
            }

            //if (estaciones[3] > 0)
            //{
            //    // Importamos las tablas de variables de la estación S4
            //    root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\TagTables\\S4 Almacen");
            //    files = root.GetFiles(".");
            //    foreach (FileInfo file in files)
            //    {
            //        tables.Import(new FileInfo(file.FullName), ImportOptions.Override);
            //    }
            //}

            if (estaciones[4] > 0)
            {
                // Importamos las tablas de variables de la estación ST
                root = new DirectoryInfo(DirectorioActual + "\\Programas\\HMI\\TagTables\\ST Sistema Transporte");
                files = root.GetFiles(".");
                foreach (FileInfo file in files)
                {
                    tables.Import(new FileInfo(file.FullName), ImportOptions.Override);
                }
            }
        }

    }
}
